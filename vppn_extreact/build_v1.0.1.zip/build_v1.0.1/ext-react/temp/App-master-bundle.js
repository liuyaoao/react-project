// @tag App
// @require D:\github_pro\react-project\vppn_extreact\build\ext-react\app.js
